The three subdirectories here hold project-specific commandfiles, site aliases, and configuration for Drush. See http://packages.drush.org/ for a directory of Drush commands installable via Composer.
